## Packages
framer-motion | Complex animations for scroll reveals and hero section
react-intersection-observer | For scroll-triggered animations
lucide-react | Icons for services and features (already in base, but emphasizing use)

## Notes
- Using Google Fonts: 'Inter' for body and 'Roboto' for headings (via index.css)
- API: POST /api/contact for contact form submission
- Images: Using Unsplash for hero and service backgrounds where appropriate, plus the provided logo URL
- Colors: Deep Navy Blue (#1e293b) and Muted Orange/Gold (#d97706)

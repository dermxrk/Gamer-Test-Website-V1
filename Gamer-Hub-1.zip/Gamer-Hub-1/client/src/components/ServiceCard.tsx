import { LucideIcon } from "lucide-react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";

interface ServiceCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  features: string[];
  delay?: number;
}

export function ServiceCard({ icon: Icon, title, description, features, delay = 0 }: ServiceCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
    >
      <Card className="h-full border-none shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white overflow-hidden group">
        <div className="h-2 bg-accent w-0 group-hover:w-full transition-all duration-500 ease-out" />
        <CardContent className="p-8">
          <div className="mb-6 inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/5 text-primary group-hover:bg-primary group-hover:text-white transition-colors duration-300">
            <Icon className="w-8 h-8" />
          </div>
          
          <h3 className="text-2xl font-bold mb-3 text-primary">{title}</h3>
          <p className="text-muted-foreground mb-6 leading-relaxed">
            {description}
          </p>
          
          <ul className="space-y-2">
            {features.map((feature, idx) => (
              <li key={idx} className="flex items-center text-sm font-medium text-gray-600">
                <span className="w-1.5 h-1.5 rounded-full bg-accent mr-2" />
                {feature}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </motion.div>
  );
}

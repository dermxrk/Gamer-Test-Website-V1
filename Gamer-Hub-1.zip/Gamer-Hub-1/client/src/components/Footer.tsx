import { ShieldCheck, Phone, Mail, MapPin } from "lucide-react";

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary text-primary-foreground pt-16 pb-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <ShieldCheck className="w-8 h-8 text-accent" />
              <span className="text-2xl font-black tracking-tight">Gamer GmbH</span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              Ihr zuverlässiger Partner für Sanitär, Heizung und Blechnerei in Karlsruhe. 
              Tradition und Moderne seit Generationen vereint.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold mb-4 text-white">Navigation</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#home" className="hover:text-accent transition-colors">Home</a></li>
              <li><a href="#about" className="hover:text-accent transition-colors">Über uns</a></li>
              <li><a href="#services" className="hover:text-accent transition-colors">Leistungen</a></li>
              <li><a href="#contact" className="hover:text-accent transition-colors">Kontakt</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-bold mb-4 text-white">Kontakt</h4>
            <ul className="space-y-4 text-sm text-gray-400">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-accent shrink-0" />
                <span>Gamer GmbH<br />G.-Braun-Str. 7<br />76187 Karlsruhe</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-accent shrink-0" />
                <a href="tel:+49721000000" className="hover:text-white transition-colors">0721 / 56 22 22</a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-accent shrink-0" />
                <a href="mailto:info@gamer.de" className="hover:text-white transition-colors">info@gamer.de</a>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="text-lg font-bold mb-4 text-white">Rechtliches</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="/impressum" className="hover:text-accent transition-colors">Impressum</a></li>
              <li><a href="/datenschutz" className="hover:text-accent transition-colors">Datenschutz</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 text-center text-sm text-gray-500">
          <p>&copy; {currentYear} Gamer GmbH. Alle Rechte vorbehalten. Handwerk mit Leidenschaft.</p>
        </div>
      </div>
    </footer>
  );
}

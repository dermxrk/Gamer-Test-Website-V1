import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { motion } from "framer-motion";

export default function Impressum() {
  return (
    <div className="min-h-screen bg-background font-sans">
      <Navigation />
      
      <main className="pt-32 pb-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl font-black text-primary mb-8">Impressum</h1>
            
            <div className="prose prose-slate max-w-none">
              <section className="mb-12">
                <h2 className="text-2xl font-bold text-primary mb-4">Angaben gemäß § 5 TMG</h2>
                <p className="text-lg">
                  Fa. Gamer GmbH<br />
                  Blechnerei & Installation<br />
                  G.-Braun-Straße 7<br />
                  76187 Karlsruhe
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-bold text-primary mb-4">Kontakt</h2>
                <p className="text-lg">
                  Telefon: 0721-613 831<br />
                  Telefax: 0721-621 812<br />
                  E-Mail: <a href="mailto:info@gamer.de" className="text-accent hover:underline">info@gamer.de</a><br />
                  Web: <a href="http://www.gamer.de" target="_blank" rel="noopener noreferrer" className="text-accent hover:underline">www.gamer.de</a>
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-bold text-primary mb-4">Registereintrag</h2>
                <p className="text-lg">
                  Registergericht: Amtsgericht Mannheim<br />
                  Registernummer: HRB 103806<br />
                  Umsatzsteuer-Identifikationsnummer gemäß §27 a Umsatzsteuergesetz: DE 143 595 721
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-bold text-primary mb-4">Vertreten durch</h2>
                <p className="text-lg">
                  Gesellschafter / Verantwortlich: Thomas Gamer
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-bold text-primary mb-4">Haftungshinweis</h2>
                <p className="text-gray-600 leading-relaxed">
                  Ich habe meinen Internetauftritt sorgfältig bearbeitet und schließe hiermit Haftungsansprüche aus. 
                  Die Verweise auf andere Seiten wurden von mir zum Zeitpunkt der Linksetzung auf Legalität geprüft. 
                  Falls die verlinkten Webseitenbetreiber die Inhalte der verlinkten Seiten nachträglich geändert haben, 
                  distanziere ich mich hiermit davon und übernehme keinerlei Haftung.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-bold text-primary mb-4">Urheberrecht</h2>
                <p className="text-gray-600 leading-relaxed">
                  Die eigenen Inhalte meiner Seite unterliegen dem Urheberrecht. Eine Veröffentlichung in andere Medien, 
                  auch elektronischen Medienbedarf meiner ausdrücklichen Zustimmung. Meine persönlichen Fotografien 
                  sind mein Eigentum und dürfen ohne Anfrage auf keinen Fall kopiert oder veröffentlicht werden.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="text-2xl font-bold text-primary mb-4">Quelle Bildmaterial</h2>
                <p className="text-sm text-gray-500 italic">
                  IStockphoto.de, Fotolia.com<br />
                  © Surrender, © Kzenon, © fotobi, © Christian Stoll, © toolklickit, © Vadim Andrushchenko,
                  © haveseen, © flashpics, © CLUPIX, © nsj-images, © tulcarion, © Atanas Bezov, © froxx,
                  © zolwik, © Julien Rousset, © Geberit, © gamer
                </p>
              </section>
            </div>
          </motion.div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}

import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertContactMessageSchema } from "@shared/schema";
import { motion } from "framer-motion";
import { 
  Wrench, Droplets, Flame, Sun, ShieldCheck, 
  ArrowRight, CheckCircle2, Phone, Hammer 
} from "lucide-react";

import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { ServiceCard } from "@/components/ServiceCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useSubmitContact } from "@/hooks/use-contact";

export default function Home() {
  const form = useForm({
    resolver: zodResolver(insertContactMessageSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      message: ""
    }
  });

  const contactMutation = useSubmitContact();

  const onSubmit = (data: any) => {
    contactMutation.mutate(data, {
      onSuccess: () => form.reset()
    });
  };

  return (
    <div className="min-h-screen bg-background font-sans">
      <Navigation />

      {/* Hero Section */}
      <section id="home" className="relative h-screen min-h-[700px] flex items-center justify-center overflow-hidden">
        {/* Background Image with Overlay */}
        <div className="absolute inset-0 z-0">
          {/* Unsplash image: Modern bathroom interior */}
          <img 
            src="https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?q=80&w=2000&auto=format&fit=crop"
            alt="Modernes Bad Handwerk"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-primary/95 to-primary/40" />
        </div>

        <div className="container relative z-10 px-4 sm:px-6 lg:px-8 pt-20">
          <div className="max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="inline-block px-4 py-2 rounded-full bg-accent/20 border border-accent/30 backdrop-blur-sm mb-6">
                <span className="text-accent font-bold uppercase tracking-wider text-sm">
                  Meisterbetrieb in Karlsruhe seit 1937
                </span>
              </div>
              
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-black text-white mb-6 leading-tight drop-shadow-lg">
                Blechnerei.<br />Sanitär.<br />Heizung.
              </h1>
              
              <p className="text-xl md:text-2xl text-gray-200 mb-10 leading-relaxed max-w-2xl text-shadow">
                Qualität, Tradition und moderne Technik seit Generationen. 
                Ihr verlässlicher Partner für Bad, Wärme und Solar.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="bg-accent hover:bg-accent/90 text-white font-bold text-lg px-8 py-6 shadow-xl shadow-accent/20"
                  onClick={() => document.querySelector("#services")?.scrollIntoView({ behavior: "smooth" })}
                >
                  Unsere Leistungen
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
                
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="border-white/30 bg-white/10 hover:bg-white/20 text-white backdrop-blur-sm font-bold text-lg px-8 py-6"
                  onClick={() => document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" })}
                >
                  <Phone className="mr-2 w-5 h-5" />
                  Kontakt aufnehmen
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-accent font-bold tracking-widest uppercase mb-3 text-sm">Das Unternehmen</h2>
              <h3 className="text-4xl font-black text-primary mb-6">Tradition trifft Innovation.</h3>
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                Als etablierter Meisterbetrieb in Karlsruhe verbinden wir stolze Handwerkskunst mit modernster Technik. 
                Unsere Stärke liegt nicht nur in der fachgerechten Ausführung, sondern in der persönlichen Beratung und Planung Ihrer Projekte.
              </p>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                Ob filigrane Blechnerei, energieeffiziente Heizsysteme oder Ihr persönliches Traumbad – 
                wir setzen auf Qualität, die bleibt.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {["Langjährige Erfahrung", "Kompetenter Fachbetrieb", "Persönliche Beratung", "Meisterqualität"].map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-accent flex-shrink-0" />
                    <span className="font-semibold text-primary">{item}</span>
                  </div>
                ))}
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative"
            >
              <div className="absolute -inset-4 bg-primary/5 rounded-3xl transform rotate-3" />
              <img 
                src="/images/zertifikat.jpg"
                alt="SHK-Fachkundiger Zertifikat"
                className="relative rounded-2xl shadow-2xl object-contain h-[500px] w-full bg-white p-4"
              />
              <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-xl shadow-xl border border-gray-100 max-w-xs">
                <div className="flex items-center gap-4">
                  <div className="bg-accent/10 p-3 rounded-full">
                    <ShieldCheck className="w-8 h-8 text-accent" />
                  </div>
                  <div>
                    <p className="font-bold text-primary text-lg">Zertifizierter Betrieb</p>
                    <p className="text-sm text-gray-500">Qualität durch Ausbildung.</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section id="services" className="py-24 bg-slate-50 relative clip-path-slant pb-48">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-accent font-bold tracking-widest uppercase mb-3 text-sm">Unsere Leistungen</h2>
            <h3 className="text-4xl font-black text-primary mb-6">Handwerk in Perfektion.</h3>
            <p className="text-lg text-muted-foreground">
              Von der Planung bis zur Fertigstellung bieten wir Ihnen umfassende Lösungen aus einer Hand.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <ServiceCard 
              icon={Hammer}
              title="Blechnerei"
              description="Präzise Metallarbeiten für Dach und Fassade. Langlebig und ästhetisch."
              features={["Falztechniken", "Dachabdichtungen", "Gaubenverkleidung", "Denkmalschutz"]}
              delay={0}
            />
            <ServiceCard 
              icon={Droplets}
              title="Bäder"
              description="Verwandeln Sie Ihr Bad in eine Wellness-Oase. Modern, funktional, schön."
              features={["Komplettsanierung", "Barrierefreie Bäder", "3D-Badplanung", "Sanitäre Anlagen"]}
              delay={0.1}
            />
            <ServiceCard 
              icon={Flame}
              title="Heizung"
              description="Wärme mit System. Effizient, kostensparend und zukunftssicher."
              features={["Wärmepumpen", "Gas- & Ölheizung", "Fußbodenheizung", "Wartungsservice"]}
              delay={0.2}
            />
            <ServiceCard 
              icon={Sun}
              title="Solar"
              description="Nutzen Sie die Kraft der Sonne. Nachhaltige Energie für Ihr Zuhause."
              features={["Solarthermie", "Photovoltaik", "Speichersysteme", "Fördermittelberatung"]}
              delay={0.3}
            />
          </div>
        </div>
      </section>

      {/* Special Service USPs */}
      <section id="special-service" className="py-24 bg-white -mt-24 pt-32">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="bg-primary text-white rounded-3xl p-10 shadow-2xl relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
                <Wrench className="w-40 h-40" />
              </div>
              <h3 className="text-3xl font-bold mb-6">Spezial-Service</h3>
              <div className="space-y-8 relative z-10">
                <div className="flex gap-4">
                  <div className="w-12 h-12 rounded-xl bg-accent flex items-center justify-center flex-shrink-0">
                    <span className="font-bold text-xl">1</span>
                  </div>
                  <div>
                    <h4 className="text-xl font-bold mb-2 text-white">Gasleitungs-Sanierung</h4>
                    <p className="text-gray-300">
                      Innenabdichtung von Gasleitungen durch Ausschäumen. Sauber, sicher und ohne Wände aufzubrechen.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-12 h-12 rounded-xl bg-accent flex items-center justify-center flex-shrink-0">
                    <span className="font-bold text-xl">2</span>
                  </div>
                  <div>
                    <h4 className="text-xl font-bold mb-2 text-white">Bautrocknung</h4>
                    <p className="text-gray-300">
                      Professioneller Verleih von Trocknungsgeräten bei Wasserschäden. Schnelle Hilfe im Notfall.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-8 flex flex-col justify-center">
              <div>
                <h3 className="text-3xl font-black text-primary mb-6">Besondere Kompetenzen.</h3>
                <p className="text-lg text-muted-foreground mb-8">
                  Neben unseren Kernleistungen bieten wir spezialisierte Services an, die uns von anderen Betrieben abheben.
                </p>
              </div>

              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 hover:border-accent/50 transition-colors">
                <h4 className="font-bold text-primary text-lg mb-2">Edelstahl-Verteiler nach Maß</h4>
                <p className="text-gray-600">
                  Wir fertigen individuelle Edelstahlverteiler für Industrie und Privat – passgenau für Ihre Anforderungen.
                </p>
              </div>

              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 hover:border-accent/50 transition-colors">
                <h4 className="font-bold text-primary text-lg mb-2">Seniorenfreundlicher Service</h4>
                <p className="text-gray-600">
                  Zertifiziert und geschult: Wir beraten und installieren barrierefreie Lösungen für ein sicheres Wohnen im Alter.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 bg-slate-900 text-white relative">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-[20%] -right-[10%] w-[600px] h-[600px] bg-accent/10 rounded-full blur-3xl" />
          <div className="absolute bottom-[10%] left-[10%] w-[400px] h-[400px] bg-primary/40 rounded-full blur-3xl" />
        </div>

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <div>
              <h2 className="text-accent font-bold tracking-widest uppercase mb-3 text-sm">Kontakt</h2>
              <h3 className="text-4xl font-black text-white mb-6">Wir sind für Sie da.</h3>
              <p className="text-xl text-gray-400 mb-10 leading-relaxed">
                Haben Sie Fragen zu unseren Leistungen oder wünschen Sie ein unverbindliches Angebot? 
                Schreiben Sie uns oder rufen Sie uns an.
              </p>

              <div className="space-y-6 mb-12">
                <div className="flex items-center gap-4 text-lg">
                  <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center border border-white/20">
                    <Phone className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-400 uppercase tracking-wider">Telefon</p>
                    <a href="tel:0721562222" className="font-bold hover:text-accent transition-colors">0721 / 56 22 22</a>
                  </div>
                </div>
                
                <div className="flex items-center gap-4 text-lg">
                  <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center border border-white/20">
                    <ShieldCheck className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-400 uppercase tracking-wider">Notdienst</p>
                    <p className="font-bold">24h für Vertragskunden</p>
                  </div>
                </div>
              </div>

              <div className="p-6 bg-white/5 rounded-2xl border border-white/10">
                <h4 className="font-bold mb-4">Öffnungszeiten</h4>
                <div className="grid grid-cols-2 gap-4 text-sm text-gray-400">
                  <div>Mo - Do</div>
                  <div className="text-right text-white">07:30 - 16:30 Uhr</div>
                  <div>Fr</div>
                  <div className="text-right text-white">07:30 - 13:00 Uhr</div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-2xl">
              <h3 className="text-2xl font-bold text-primary mb-6">Nachricht senden</h3>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-primary font-semibold">Ihr Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Max Mustermann" {...field} className="bg-gray-50 border-gray-200 focus:border-accent h-12" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-primary font-semibold">E-Mail Adresse</FormLabel>
                          <FormControl>
                            <Input placeholder="max@beispiel.de" {...field} className="bg-gray-50 border-gray-200 focus:border-accent h-12" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-primary font-semibold">Telefon (Optional)</FormLabel>
                          <FormControl>
                            <Input placeholder="Für Rückruf" {...field} className="bg-gray-50 border-gray-200 focus:border-accent h-12" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-primary font-semibold">Ihre Nachricht</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Wie können wir Ihnen helfen?" 
                            className="resize-none min-h-[120px] bg-gray-50 border-gray-200 focus:border-accent" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button 
                    type="submit" 
                    className="w-full h-14 bg-accent hover:bg-accent/90 text-white font-bold text-lg shadow-lg"
                    disabled={contactMutation.isPending}
                  >
                    {contactMutation.isPending ? "Wird gesendet..." : "Nachricht absenden"}
                  </Button>
                </form>
              </Form>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
